import { PrismaClient, UserRole } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const adminPin = await bcrypt.hash("1111", 12);
  const operatorPin = await bcrypt.hash("2222", 12);

  await prisma.user.upsert({ where: { id: 1 }, update: {}, create: { name: "Administrador", pinHash: adminPin, role: UserRole.ADMIN } });
  await prisma.user.upsert({ where: { id: 2 }, update: {}, create: { name: "Operador Demo", pinHash: operatorPin, role: UserRole.OPERATOR } });

  for (const code of ["1","2","3","4","5","6","7"]) {
    await prisma.machine.upsert({ where: { code }, update: {}, create: { code, name: `Máquina ${code}` } });
  }

  const products = [
    ["GAR-05-HDPE", "Garrafão 5 L HDPE", "Jerrycan"],
    ["GAR-10-HDPE", "Garrafão 10 L HDPE", "Jerrycan"],
    ["GAR-20-HDPE", "Garrafão 20 L HDPE", "Jerrycan"]
  ];
  for (const [code,name,packageType] of products) {
    await prisma.product.upsert({ where: { code }, update: {}, create: { code, name, packageType } });
  }

  const materials = [
    ["PEAD-NAT", "PEAD Natural"],
    ["PEAD-REC", "PEAD Reciclado"],
    ["MB-AZUL", "Masterbatch Azul"]
  ];
  for (const [code,name] of materials) {
    await prisma.rawMaterial.upsert({ where: { code }, update: {}, create: { code, name } });
  }

  const rm = await prisma.rawMaterial.findMany();
  for (const [i, material] of rm.entries()) {
    await prisma.rawMaterialLot.upsert({
      where: { rawMaterialId_supplierLot: { rawMaterialId: material.id, supplierLot: `DEMO-${i+1}-2026` } },
      update: {},
      create: { rawMaterialId: material.id, supplierLot: `DEMO-${i+1}-2026`, supplier: "Fornecedor Demo", quantityInitial: 1000, quantityAvailable: 1000 }
    });
  }

  const rule = await prisma.productionLotRule.findFirst();
  if (!rule) await prisma.productionLotRule.create({ data: { name: "Regra principal" } });
}

main().finally(() => prisma.$disconnect());
