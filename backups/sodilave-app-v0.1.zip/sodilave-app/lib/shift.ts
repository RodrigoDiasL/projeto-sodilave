export function getShift(date = new Date()) {
  const hour = date.getHours();
  if (hour >= 6 && hour < 14) return { code: "A", label: "Turno A", hours: "06:00 - 14:00" };
  if (hour >= 14 && hour < 22) return { code: "B", label: "Turno B", hours: "14:00 - 22:00" };
  return { code: "C", label: "Turno C", hours: "22:00 - 06:00" };
}
