"use server";
import bcrypt from "bcryptjs";
import { revalidatePath } from "next/cache";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";
import { UserRole } from "@prisma/client";
const b=(v:FormDataEntryValue|null)=>String(v||"")==="on";

export async function createUser(formData:FormData){const admin=await requireAdmin(); const pin=String(formData.get("pin")||""); if(!/^\d{4,8}$/.test(pin)) throw new Error("PIN inválido"); const row=await db.user.create({data:{name:String(formData.get("name")),pinHash:await bcrypt.hash(pin,12),role:String(formData.get("role")) as UserRole,active:true}}); await db.auditLog.create({data:{userId:admin.id,action:"CREATE",entity:"User",entityId:String(row.id)}}); revalidatePath("/admin/users");}
export async function createMachine(formData:FormData){await requireAdmin();await db.machine.create({data:{code:String(formData.get("code")),name:String(formData.get("name")),active:true}});revalidatePath("/admin/machines");}
export async function createProduct(formData:FormData){await requireAdmin();await db.product.create({data:{code:String(formData.get("code")),name:String(formData.get("name")),packageType:String(formData.get("packageType")||"")||null,active:true}});revalidatePath("/admin/products");}
export async function createRawMaterial(formData:FormData){await requireAdmin();await db.rawMaterial.create({data:{code:String(formData.get("code")),name:String(formData.get("name")),unit:String(formData.get("unit")||"kg"),active:true}});revalidatePath("/admin/raw-materials");}
export async function createRawMaterialLot(formData:FormData){await requireAdmin();const q=Number(formData.get("quantityInitial"));await db.rawMaterialLot.create({data:{rawMaterialId:Number(formData.get("rawMaterialId")),supplierLot:String(formData.get("supplierLot")),supplier:String(formData.get("supplier")||"")||null,quantityInitial:q,quantityAvailable:q}});revalidatePath("/admin/raw-material-lots");}
export async function createLotRule(formData:FormData){await requireAdmin();await db.productionLotRule.updateMany({data:{active:false}});await db.productionLotRule.create({data:{name:String(formData.get("name")),prefix:String(formData.get("prefix")),template:String(formData.get("template")),active:true}});revalidatePath("/admin/lot-rules");}
