"use server";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { getShift } from "@/lib/shift";
import { generateProductionLot } from "@/lib/lot";
import { RecordStatus, TestMoment, TestResult, TestType } from "@prisma/client";

const asNum = (v: FormDataEntryValue | null) => v === null || v === "" ? null : Number(v);

export async function saveProduction(formData: FormData) {
  const user = await requireUser();
  const machineId = Number(formData.get("machineId"));
  const productId = Number(formData.get("productId"));
  const intent = String(formData.get("intent") || "draft");
  const productionId = asNum(formData.get("productionId"));
  if (!machineId || !productId) throw new Error("Máquina e produto são obrigatórios.");
  const machine = await db.machine.findUniqueOrThrow({ where: { id: machineId } });
  const shift = getShift();
  const lot = productionId ? undefined : await generateProductionLot(machine.code, shift.code);
  const status = intent === "finalize" ? RecordStatus.FINALIZED : RecordStatus.DRAFT;

  const data = {
    machineId, productId, operatorId: user.id, shiftCode: shift.code, status,
    initialWeightG: asNum(formData.get("initialWeightG")), midWeightG: asNum(formData.get("midWeightG")),
    quantityProduced: asNum(formData.get("quantityProduced")), observations: String(formData.get("observations") || "") || null,
    finalizedAt: status === RecordStatus.FINALIZED ? new Date() : null
  };
  const production = productionId
    ? await db.production.update({ where: { id: productionId }, data })
    : await db.production.create({ data: { ...data, productionLot: lot! } });

  await db.productionMaterial.deleteMany({ where: { productionId: production.id } });
  for (let i=0; i<8; i++) {
    const rawMaterialLotId = asNum(formData.get(`materialLotId_${i}`));
    if (!rawMaterialLotId) continue;
    await db.productionMaterial.create({ data: { productionId: production.id, rawMaterialLotId, percentage: asNum(formData.get(`percentage_${i}`)), quantityKg: asNum(formData.get(`quantityKg_${i}`)) } });
  }

  await db.qualityTest.deleteMany({ where: { productionId: production.id } });
  const tests: [TestType, TestMoment, string][] = [
    [TestType.LEAK, TestMoment.START, "leakStart"], [TestType.LEAK, TestMoment.MID, "leakMid"],
    [TestType.DROP, TestMoment.START, "dropStart"], [TestType.DROP, TestMoment.MID, "dropMid"]
  ];
  for (const [type,moment,key] of tests) {
    const value = String(formData.get(key) || "");
    if (value) await db.qualityTest.create({ data: { productionId: production.id, type, moment, result: value as TestResult } });
  }

  await db.auditLog.create({ data: { userId: user.id, action: status === RecordStatus.FINALIZED ? "FINALIZE" : "SAVE", entity: "Production", entityId: String(production.id) } });
  revalidatePath("/production"); revalidatePath("/admin/productions");
  return { ok: true, id: production.id, lot: production.productionLot, finalized: status === RecordStatus.FINALIZED };
}
