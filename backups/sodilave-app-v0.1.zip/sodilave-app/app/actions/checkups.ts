"use server";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { getShift } from "@/lib/shift";
import { OilLevel, RecordStatus } from "@prisma/client";
const n=(v:FormDataEntryValue|null)=>v===null||v===""?null:Number(v);

export async function saveMachineCheckup(formData: FormData) {
  const user=await requireUser(); const intent=String(formData.get("intent")||"draft");
  const status=intent==="finalize"?RecordStatus.FINALIZED:RecordStatus.DRAFT;
  const id=n(formData.get("checkupId"));
  const data={ machineId:Number(formData.get("machineId")), operatorId:user.id, shiftCode:getShift().code, status,
    oilTempC:n(formData.get("oilTempC")), oilLevel:(String(formData.get("oilLevel")||"")||null) as OilLevel|null,
    mouldTempC:n(formData.get("mouldTempC")), airPressure:n(formData.get("airPressure")), notes:String(formData.get("notes")||"")||null,
    finalizedAt:status===RecordStatus.FINALIZED?new Date():null };
  const row=id?await db.machineCheckup.update({where:{id},data}):await db.machineCheckup.create({data});
  await db.auditLog.create({data:{userId:user.id,action:status==="FINALIZED"?"FINALIZE":"SAVE",entity:"MachineCheckup",entityId:String(row.id)}});
  revalidatePath("/checkups"); return {ok:true,id:row.id,finalized:status===RecordStatus.FINALIZED};
}

export async function saveGeneralCheck(formData: FormData) {
  const user=await requireUser(); const intent=String(formData.get("intent")||"draft");
  const status=intent==="finalize"?RecordStatus.FINALIZED:RecordStatus.DRAFT; const id=n(formData.get("generalId"));
  const data={ operatorId:user.id, shiftCode:getShift().code, status, chillerLargeC:n(formData.get("chillerLargeC")), chillerSmallC:n(formData.get("chillerSmallC")),
    cleanDispatch:formData.get("cleanDispatch")==="on",cleanStorage:formData.get("cleanStorage")==="on",cleanProduction:formData.get("cleanProduction")==="on",
    notes:String(formData.get("generalNotes")||"")||null,finalizedAt:status===RecordStatus.FINALIZED?new Date():null };
  const row=id?await db.shiftGeneralCheck.update({where:{id},data}):await db.shiftGeneralCheck.create({data});
  await db.auditLog.create({data:{userId:user.id,action:status==="FINALIZED"?"FINALIZE":"SAVE",entity:"ShiftGeneralCheck",entityId:String(row.id)}});
  revalidatePath("/checkups"); return {ok:true,id:row.id,finalized:status===RecordStatus.FINALIZED};
}
