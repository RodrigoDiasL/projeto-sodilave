import { db } from "@/lib/db";
import { PageIntro } from "@/components/PageIntro";
import { ProductionForm } from "@/components/ProductionForm";

export default async function ProductionPage() {
  const [machineRows, productRows, lotRows] = await Promise.all([
    db.machine.findMany({ where: { active: true }, orderBy: { code: "asc" } }),
    db.product.findMany({ where: { active: true }, orderBy: { name: "asc" } }),
    db.rawMaterialLot.findMany({
      where: { status: "ACTIVE", quantityAvailable: { gt: 0 } },
      include: { rawMaterial: true },
      orderBy: { receivedAt: "asc" },
    }),
  ]);

  const machines = machineRows.map(({ id, code, name }) => ({ id, code, name }));
  const products = productRows.map(({ id, code, name }) => ({ id, code, name }));
  const lots = lotRows.map((lot) => ({
    id: lot.id,
    supplierLot: lot.supplierLot,
    quantityAvailable: String(lot.quantityAvailable),
    rawMaterial: { name: lot.rawMaterial.name },
  }));

  return (
    <>
      <PageIntro title="Registar Produção" subtitle="Preencha os dados da produção da máquina selecionada." />
      <ProductionForm machines={machines} products={products} lots={lots} />
    </>
  );
}
