"use client";

import { useMemo, useState } from "react";
import { saveProduction } from "@/app/actions/production";

type Machine = { id: number; code: string; name: string };
type Product = { id: number; code: string; name: string };
type RawMaterial = { id: number; name: string };
type Lot = { id: number; supplierLot: string; quantityAvailable: string; rawMaterial: { id: number; name: string } };
type MaterialRowState = { key: number; materialId: string; lotId: string; percentage: number; quantityKg: string };

const results = ["CONFORMING", "NON_CONFORMING", "NOT_PERFORMED", "NOT_APPLICABLE"];

export function ProductionForm({ machines, products, rawMaterials, lots }: { machines: Machine[]; products: Product[]; rawMaterials: RawMaterial[]; lots: Lot[] }) {
  const [rows, setRows] = useState<MaterialRowState[]>([{ key: 0, materialId: "", lotId: "", percentage: 100, quantityKg: "" }]);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const percentageTotal = useMemo(() => rows.reduce((sum, row) => sum + (row.lotId ? row.percentage : 0), 0), [rows]);
  const quantityTotal = useMemo(() => rows.reduce((sum, row) => sum + (row.quantityKg ? Number(row.quantityKg) : 0), 0), [rows]);

  const addRow = () => {
    setRows((current) => current.length >= 8 ? current : [...current, { key: Date.now(), materialId: "", lotId: "", percentage: 5, quantityKg: "" }]);
  };

  const updateRow = (key: number, patch: Partial<MaterialRowState>) => {
    setRows((current) => current.map((row) => row.key === key ? { ...row, ...patch } : row));
  };

  const removeRow = (key: number) => {
    setRows((current) => {
      const next = current.filter((row) => row.key !== key);
      return next.length === 1 ? [{ ...next[0], percentage: 100 }] : next;
    });
  };

  const validateMixture = () => {
    const selected = rows.filter((row) => row.lotId);
    if (selected.length === 0) return "Adicione pelo menos um lote de matéria-prima.";
    if (selected.some((row) => row.percentage < 5 || row.percentage > 100 || row.percentage % 5 !== 0)) return "As percentagens devem variar de 5% em 5%.";
    if (selected.reduce((sum, row) => sum + row.percentage, 0) !== 100) return "A soma das percentagens da mistura tem de ser exatamente 100%.";
    if (selected.some((row) => row.quantityKg !== "" && Number(row.quantityKg) <= 0)) return "As quantidades introduzidas têm de ser superiores a zero.";

    const withQuantity = selected.filter((row) => row.quantityKg !== "");
    if (withQuantity.length > 0 && withQuantity.length !== selected.length) return "Preencha a quantidade de todos os materiais ou deixe todas as quantidades vazias.";
    if (withQuantity.length > 0) {
      const total = withQuantity.reduce((sum, row) => sum + Number(row.quantityKg), 0);
      for (const row of withQuantity) {
        const expected = (Number(row.quantityKg) / total) * 100;
        if (Math.abs(expected - row.percentage) > 0.6) return "As quantidades não correspondem às percentagens selecionadas.";
        const lot = lots.find((item) => String(item.id) === row.lotId);
        if (lot && Number(row.quantityKg) > Number(lot.quantityAvailable)) return `A quantidade indicada excede o stock disponível do lote ${lot.supplierLot}.`;
      }
    }
    return "";
  };

  const submit = async (formData: FormData) => {
    setMessage("");
    setError("");
    const mixtureError = validateMixture();
    if (mixtureError) { setError(mixtureError); return; }
    if (formData.get("intent") === "finalize" && !confirm("Tem a certeza de que pretende finalizar este registo? Depois de finalizado, apenas um administrador poderá alterá-lo.")) return;
    try {
      const result = await saveProduction(formData);
      setMessage(result.finalized ? `Produção ${result.lot} finalizada.` : `Rascunho ${result.lot} gravado.`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Não foi possível gravar.");
    }
  };

  return <form action={submit} className="panel form-stack">
    <fieldset><legend>Selecione a máquina *</legend><div className="machine-grid">{machines.map((m) => <label className="machine-option" key={m.id}><input type="radio" name="machineId" value={m.id} required/><span>⚙</span><strong>{m.code}</strong></label>)}</div></fieldset>
    <div className="two-col">
      <label>Tipo de embalagem produzido *<select name="productId" required><option value="">Selecione o tipo de embalagem</option>{products.map((p) => <option key={p.id} value={p.id}>{p.code} — {p.name}</option>)}</select></label>
      <div><label>Lotes de matérias-primas consumidas *</label><button type="button" className="btn secondary" onClick={addRow}>+ Adicionar lote</button></div>
    </div>

    <section className="subpanel">
      <h3>Mistura / Lotes utilizados</h3>
      {rows.map((row, index) => <MaterialRow key={row.key} index={index} row={row} required={index === 0} rawMaterials={rawMaterials} lots={lots} removable={rows.length > 1} onChange={(patch) => updateRow(row.key, patch)} onRemove={() => removeRow(row.key)}/>) }
      <div className={`mixture-summary ${percentageTotal === 100 ? "valid" : "invalid"}`}>
        <strong>Total: {percentageTotal}%</strong>
        <span>{quantityTotal > 0 ? `${quantityTotal.toFixed(3)} kg no total` : "Quantidades opcionais"}</span>
      </div>
    </section>

    <section className="subpanel"><h3>Peso da embalagem (g)</h3><div className="two-col">
      <label>Início do turno<input className="no-spinner" name="initialWeightG" type="number" step="1" min="1" max="100000" inputMode="numeric" placeholder="Ex.: 1250"/></label>
      <label>Meio do turno<input className="no-spinner" name="midWeightG" type="number" step="1" min="1" max="100000" inputMode="numeric" placeholder="Ex.: 1250"/></label>
    </div></section>

    <div className="two-col">
      <section className="subpanel"><h3>Teste de vedação</h3><div className="two-col compact"><label>Início<select name="leakStart"><option value="">Selecione</option>{results.map((x) => <option key={x} value={x}>{labelResult(x)}</option>)}</select></label><label>Meio<select name="leakMid"><option value="">Selecione</option>{results.map((x) => <option key={x} value={x}>{labelResult(x)}</option>)}</select></label></div></section>
      <section className="subpanel"><h3>Teste de queda</h3><div className="two-col compact"><label>Início<select name="dropStart"><option value="">Selecione</option>{results.map((x) => <option key={x} value={x}>{labelResult(x)}</option>)}</select></label><label>Meio<select name="dropMid"><option value="">Selecione</option>{results.map((x) => <option key={x} value={x}>{labelResult(x)}</option>)}</select></label></div></section>
    </div>

    <label>Quantidade produzida (unidades)<input className="no-spinner" name="quantityProduced" type="number" step="1" min="0" max="10000000" inputMode="numeric" placeholder="Ex.: 1500"/></label>
    <label>Observações / Comentários<textarea name="observations" maxLength={500} placeholder="Escreva aqui observações ou comentários..."/></label>
    {error && <div className="alert error">{error}</div>}{message && <div className="alert success">{message}</div>}
    <div className="button-row"><button className="btn secondary" name="intent" value="draft">Gravar</button><button className="btn primary" name="intent" value="finalize">Finalizar e registar produção</button></div>
  </form>;
}

function MaterialRow({ index, row, required, rawMaterials, lots, removable, onChange, onRemove }: { index: number; row: MaterialRowState; required: boolean; rawMaterials: RawMaterial[]; lots: Lot[]; removable: boolean; onChange: (patch: Partial<MaterialRowState>) => void; onRemove: () => void }) {
  const available = lots.filter((lot) => String(lot.rawMaterial.id) === row.materialId);
  return <div className="material-row material-row-slider">
    <select value={row.materialId} onChange={(e) => onChange({ materialId: e.target.value, lotId: "" })} required={required}><option value="">Selecione a matéria-prima</option>{rawMaterials.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</select>
    <select name={`materialLotId_${index}`} value={row.lotId} onChange={(e) => onChange({ lotId: e.target.value })} required={required} disabled={!row.materialId}><option value="">{row.materialId && available.length === 0 ? "Sem lotes disponíveis" : "Selecione o lote"}</option>{available.map((lot) => <option key={lot.id} value={lot.id}>{lot.supplierLot} · {lot.quantityAvailable} kg disponíveis</option>)}</select>
    <label className="range-field"><span>Percentagem: <strong>{row.percentage}%</strong></span><input name={`percentage_${index}`} type="range" min="5" max="100" step="5" value={row.percentage} onChange={(e) => onChange({ percentage: Number(e.target.value) })}/></label>
    <input className="no-spinner" name={`quantityKg_${index}`} value={row.quantityKg} onChange={(e) => onChange({ quantityKg: e.target.value })} type="number" step="0.001" min="0.001" max="999999" inputMode="decimal" placeholder="Quantidade (kg)"/>
    {removable && <button type="button" className="icon-btn danger" onClick={onRemove} aria-label="Remover matéria-prima">×</button>}
  </div>;
}

function labelResult(x: string) { return { CONFORMING: "Conforme", NON_CONFORMING: "Não conforme", NOT_PERFORMED: "Não realizado", NOT_APPLICABLE: "Não aplicável" }[x]; }
