"use server";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { getShift } from "@/lib/shift";
import { generateProductionLot } from "@/lib/lot";
import { RecordStatus, TestMoment, TestResult, TestType } from "@prisma/client";

const asNum = (v: FormDataEntryValue | null) => v === null || v === "" ? null : Number(v);
const finiteInRange = (value: number | null, min: number, max: number, label: string, integer = false) => {
  if (value === null) return;
  if (!Number.isFinite(value) || value < min || value > max || (integer && !Number.isInteger(value))) throw new Error(`${label} tem um valor inválido.`);
};

export async function saveProduction(formData: FormData) {
  const user = await requireUser();
  const machineId = Number(formData.get("machineId"));
  const productId = Number(formData.get("productId"));
  const intent = String(formData.get("intent") || "draft");
  const productionId = asNum(formData.get("productionId"));
  if (!Number.isInteger(machineId) || machineId <= 0 || !Number.isInteger(productId) || productId <= 0) throw new Error("Máquina e produto são obrigatórios.");
  if (!['draft', 'finalize'].includes(intent)) throw new Error("Ação inválida.");

  const initialWeightG = asNum(formData.get("initialWeightG"));
  const midWeightG = asNum(formData.get("midWeightG"));
  const quantityProduced = asNum(formData.get("quantityProduced"));
  finiteInRange(initialWeightG, 1, 100000, "O peso inicial", true);
  finiteInRange(midWeightG, 1, 100000, "O peso intermédio", true);
  finiteInRange(quantityProduced, 0, 10000000, "A quantidade produzida", true);

  const materials: { rawMaterialLotId: number; percentage: number | null; quantityKg: number | null }[] = [];
  for (let i = 0; i < 8; i++) {
    const rawMaterialLotId = asNum(formData.get(`materialLotId_${i}`));
    if (!rawMaterialLotId) continue;
    const percentage = asNum(formData.get(`percentage_${i}`));
    const quantityKg = asNum(formData.get(`quantityKg_${i}`));
    finiteInRange(percentage, 5, 100, "A percentagem");
    if (percentage! % 5 !== 0) throw new Error("As percentagens devem variar de 5% em 5%.");
    finiteInRange(quantityKg, 0.001, 999999, "A quantidade de matéria-prima");
    materials.push({ rawMaterialLotId, percentage, quantityKg });
  }
  if (materials.length === 0) throw new Error("Adicione pelo menos um lote de matéria-prima.");
  if (materials.reduce((sum, row) => sum + (row.percentage ?? 0), 0) !== 100) throw new Error("A soma das percentagens da mistura tem de ser 100%.");
  const quantities = materials.filter((row) => row.quantityKg !== null);
  if (quantities.length > 0 && quantities.length !== materials.length) throw new Error("Preencha todas as quantidades da mistura ou deixe-as todas vazias.");
  if (quantities.length > 0) {
    const total = quantities.reduce((sum, row) => sum + row.quantityKg!, 0);
    for (const row of quantities) {
      const expected = (row.quantityKg! / total) * 100;
      if (Math.abs(expected - row.percentage!) > 0.6) throw new Error("As quantidades não correspondem às percentagens selecionadas.");
    }
  }

  const lotRows = await db.rawMaterialLot.findMany({ where: { id: { in: materials.map((row) => row.rawMaterialLotId) }, status: "ACTIVE" } });
  if (lotRows.length !== materials.length) throw new Error("Um dos lotes selecionados já não está disponível.");
  for (const material of materials) {
    const lotRow = lotRows.find((lot) => lot.id === material.rawMaterialLotId)!;
    if (material.quantityKg !== null && material.quantityKg > Number(lotRow.quantityAvailable)) throw new Error(`A quantidade excede o stock disponível do lote ${lotRow.supplierLot}.`);
  }

  const machine = await db.machine.findFirst({ where: { id: machineId, active: true } });
  const product = await db.product.findFirst({ where: { id: productId, active: true } });
  if (!machine || !product) throw new Error("A máquina ou o produto selecionado já não está ativo.");
  const shift = getShift();
  const lot = productionId ? undefined : await generateProductionLot(machine.code, shift.code);
  const status = intent === "finalize" ? RecordStatus.FINALIZED : RecordStatus.DRAFT;

  const data = {
    machineId, productId, operatorId: user.id, shiftCode: shift.code, status,
    initialWeightG, midWeightG, quantityProduced,
    observations: String(formData.get("observations") || "").trim().slice(0, 500) || null,
    finalizedAt: status === RecordStatus.FINALIZED ? new Date() : null,
  };
  const production = productionId
    ? await db.production.update({ where: { id: productionId }, data })
    : await db.production.create({ data: { ...data, productionLot: lot! } });

  await db.productionMaterial.deleteMany({ where: { productionId: production.id } });
  await db.productionMaterial.createMany({ data: materials.map((row) => ({ productionId: production.id, ...row })) });

  await db.qualityTest.deleteMany({ where: { productionId: production.id } });
  const tests: [TestType, TestMoment, string][] = [
    [TestType.LEAK, TestMoment.START, "leakStart"], [TestType.LEAK, TestMoment.MID, "leakMid"],
    [TestType.DROP, TestMoment.START, "dropStart"], [TestType.DROP, TestMoment.MID, "dropMid"],
  ];
  const validResults = Object.values(TestResult);
  for (const [type, moment, key] of tests) {
    const value = String(formData.get(key) || "");
    if (value && validResults.includes(value as TestResult)) await db.qualityTest.create({ data: { productionId: production.id, type, moment, result: value as TestResult } });
  }

  await db.auditLog.create({ data: { userId: user.id, action: status === RecordStatus.FINALIZED ? "FINALIZE" : "SAVE", entity: "Production", entityId: String(production.id) } });
  revalidatePath("/production"); revalidatePath("/admin/productions");
  return { ok: true, id: production.id, lot: production.productionLot, finalized: status === RecordStatus.FINALIZED };
}
