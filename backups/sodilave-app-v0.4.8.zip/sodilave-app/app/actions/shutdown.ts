"use server";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { getShift } from "@/lib/shift";
import { RecordStatus } from "@prisma/client";

export async function saveWeeklyShutdown(fd: FormData){
  const user=await requireUser();
  const finalize=String(fd.get("intent"))==="finalize";
  const id=Number(fd.get("shutdownId")||0);
  const startup=await db.weeklyStartup.findFirst({where:{status:RecordStatus.FINALIZED,shutdown:null},orderBy:{startupDate:"desc"},include:{machines:{include:{machine:true}}}});
  if(!startup) throw new Error("Não existe um arranque semanal ativo para encerrar.");
  const data={operatorId:user.id,weeklyStartupId:startup.id,status:finalize?RecordStatus.FINALIZED:RecordStatus.DRAFT,shiftCode:getShift().code,
    cleanDispatch:fd.get("cleanDispatch")==="on",cleanStorage:fd.get("cleanStorage")==="on",cleanProduction:fd.get("cleanProduction")==="on",
    observations:String(fd.get("observations")||"").trim().slice(0,1500)||null,finalizedAt:finalize?new Date():null};
  if(finalize && (!data.cleanDispatch||!data.cleanStorage||!data.cleanProduction)) throw new Error("Confirme as três limpezas gerais antes de finalizar a paragem.");
  const existing=id?await db.weeklyShutdown.findUnique({where:{id}}):await db.weeklyShutdown.findUnique({where:{weeklyStartupId:startup.id}});
  if(existing?.status===RecordStatus.FINALIZED) throw new Error("Esta paragem já foi finalizada.");
  const row=existing?await db.weeklyShutdown.update({where:{id:existing.id},data}):await db.weeklyShutdown.create({data});
  await db.weeklyShutdownMachine.deleteMany({where:{weeklyShutdownId:row.id}});
  const fields=["externalCleaning","acrylicsCleaning","mouldCleaning","traysCleaning","catchersCleaning","beltsCleaning","packingTableCleaning","waterFiltersCleaning","surroundingArea"];
  for(const item of startup.machines){
    const values=Object.fromEntries(fields.map(k=>[k,fd.get(`m${item.machineId}_${k}`)==="on"]));
    if(finalize && Object.values(values).some(v=>!v)) throw new Error(`Complete todas as limpezas da máquina ${item.machine.code}.`);
    await db.weeklyShutdownMachine.create({data:{weeklyShutdownId:row.id,machineId:item.machineId,...values,notes:String(fd.get(`m${item.machineId}_notes`)||"").trim().slice(0,500)||null}});
  }
  await db.auditLog.create({data:{userId:user.id,action:finalize?"FINALIZE":existing?"EDIT":"CREATE",entity:"WeeklyShutdown",entityId:String(row.id)}});
  revalidatePath("/shutdown");revalidatePath("/startup");revalidatePath("/dashboard");revalidatePath("/production");revalidatePath("/checkups");
  return {id:row.id,finalized:finalize};
}
