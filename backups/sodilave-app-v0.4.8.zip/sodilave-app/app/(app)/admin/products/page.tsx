import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/auth";
import { createProduct, updateProduct, deleteProduct } from "@/app/actions/admin";
import { AdminPage } from "@/components/AdminPage";
import { ConfirmDeleteButton } from "@/components/ConfirmDeleteButton";

export default async function Page(){
  await requireAdmin();
  const rows=await db.product.findMany({orderBy:{name:"asc"}});
  return <AdminPage title="Produtos" subtitle="Gerir produtos e respetivo número de unidades por embalagem.">
    <form action={createProduct} className="inline-form">
      <input name="code" placeholder="Código" maxLength={40} required/>
      <input name="name" placeholder="Designação" maxLength={120} required/>
      <input className="no-spinner" name="unitsPerPackage" type="number" min="1" step="1" placeholder="Unidades por embalagem" required/>
      <button className="btn primary">Adicionar</button>
    </form>
    <div className="responsive-table"><table><thead><tr><th>Código</th><th>Produto</th><th>Unidades por embalagem</th><th>Estado</th><th>Ações</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}>
      <td colSpan={5}><form action={updateProduct} className="table-edit-form">
        <input type="hidden" name="id" value={r.id}/>
        <input name="code" defaultValue={r.code} required/>
        <input name="name" defaultValue={r.name} required/>
        <input className="no-spinner" name="unitsPerPackage" type="number" min="1" step="1" defaultValue={r.unitsPerPackage ?? ""} required/>
        <label className="check"><input name="active" type="checkbox" defaultChecked={r.active}/>Ativo</label>
        <button className="btn secondary">Guardar alterações</button>
      </form><form action={deleteProduct}><input type="hidden" name="id" value={r.id}/><ConfirmDeleteButton label={r.active?'Eliminar / desativar':'Eliminar'} message="Eliminar este produto? Se já tiver registos, será apenas desativado."/></form></td>
    </tr>)}</tbody></table></div>
  </AdminPage>
}
