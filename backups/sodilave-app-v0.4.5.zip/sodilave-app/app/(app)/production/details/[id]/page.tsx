import { AuditTrail } from "@/components/AuditTrail";
import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { PageIntro } from "@/components/PageIntro";

const statusLabel=(s:string)=>({DRAFT:"Em aberto",FINALIZED:"Finalizada",CANCELLED:"Cancelada"}[s]||s);
const testType=(s:string)=>({LEAK:"Vedação",DROP:"Queda"}[s]||s);
const testMoment=(s:string)=>({START:"Início",MID:"Meio",END:"Fim"}[s]||s);
const testResult=(s:string)=>({CONFORMING:"Conforme",NON_CONFORMING:"Não conforme",NOT_PERFORMED:"Não realizado",NOT_APPLICABLE:"Não aplicável"}[s]||s);
const n=(v:unknown)=>v===null||v===undefined?"—":new Intl.NumberFormat("pt-PT",{maximumFractionDigits:3}).format(Number(v));

export default async function ProductionDetailsPage({params}:{params:Promise<{id:string}>}){
  await requireUser();
  const {id}=await params;
  const r=await db.production.findUnique({where:{id:Number(id)},include:{machine:true,product:true,operator:true,materials:{include:{rawMaterialLot:{include:{rawMaterial:true}}}},tests:true}});
  if(!r)notFound();
  const audit=await db.auditLog.findMany({where:{entity:"Production",entityId:String(r.id)},include:{user:true},orderBy:{createdAt:"asc"}});
  return <>
    <PageIntro title={`Produção ${r.productionLot}`} subtitle="Consulta detalhada do registo de produção." />
    <section className="panel form-stack">
      <div className="detail-grid"><p><b>Data:</b> {r.createdAt.toLocaleString("pt-PT")}</p><p><b>Turno:</b> {r.shiftCode}</p><p><b>Máquina:</b> {r.machine.code} — {r.machine.name}</p><p><b>Produto:</b> {r.product.code} — {r.product.name}</p><p><b>Operador:</b> {r.operator.name}</p><p><b>Estado:</b> {statusLabel(r.status)}</p><p><b>Peso inicial:</b> {n(r.initialWeightG)} g</p><p><b>Peso intermédio:</b> {n(r.midWeightG)} g</p><p><b>Quantidade:</b> {r.quantityProduced??"—"} un.</p></div>
      <h2>Matérias-primas</h2><div className="responsive-table"><table><thead><tr><th>Matéria-prima</th><th>Lote</th><th>Percentagem</th><th>Quantidade</th></tr></thead><tbody>{r.materials.map(m=><tr key={m.id}><td>{m.rawMaterialLot.rawMaterial.name}</td><td>{m.rawMaterialLot.supplierLot}</td><td>{n(m.percentage)}%</td><td>{n(m.quantityKg)} kg</td></tr>)}</tbody></table></div>
      <h2>Testes</h2><div className="responsive-table"><table><thead><tr><th>Teste</th><th>Momento</th><th>Resultado</th><th>Data</th></tr></thead><tbody>{r.tests.map(t=><tr key={t.id}><td>{testType(t.type)}</td><td>{testMoment(t.moment)}</td><td>{testResult(t.result)}</td><td>{t.measuredAt.toLocaleString("pt-PT")}</td></tr>)}</tbody></table></div>
      <h2>Observações</h2><p>{r.observations||"Sem observações."}</p>
      <AuditTrail rows={audit}/>
      <div className="button-row"><Link className="btn secondary" href="/production">Voltar às produções</Link>{r.status==="DRAFT"&&<Link className="btn primary" href={`/production/${r.id}`}>Continuar produção</Link>}</div>
    </section>
  </>;
}
