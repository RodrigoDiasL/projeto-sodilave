import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/auth";
import { AdminPage } from "@/components/AdminPage";
import { AuditTrail } from "@/components/AuditTrail";

const state = (value: string) => ({ DRAFT: "Rascunho", FINALIZED: "Finalizado", CANCELLED: "Cancelado" }[value] ?? value);

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  await requireAdmin(); const { id } = await params;
  const r = await db.shiftGeneralCheck.findUnique({ where: { id: Number(id) }, include: { operator: true } });
  if (!r) notFound();
  const audit = await db.auditLog.findMany({ where: { entity: "ShiftGeneralCheck", entityId: String(r.id) }, include: { user: true }, orderBy: { createdAt: "asc" } });
  return <AdminPage title="Check-up geral" subtitle="Detalhes do controlo geral do turno.">
    <div className="detail-grid"><p><b>Data:</b> {r.observedAt.toLocaleString("pt-PT")}</p><p><b>Criado por:</b> {r.operator.name}</p><p><b>Turno:</b> {r.shiftCode}</p><p><b>Estado:</b> {state(r.status)}</p><p><b>Refrigerador grande:</b> {String(r.chillerLargeC ?? "—")} °C</p><p><b>Refrigerador pequeno:</b> {String(r.chillerSmallC ?? "—")} °C</p><p><b>Limpeza expedição:</b> {r.cleanDispatch ? "Sim" : "Não"}</p><p><b>Limpeza armazenamento:</b> {r.cleanStorage ? "Sim" : "Não"}</p><p><b>Limpeza produção:</b> {r.cleanProduction ? "Sim" : "Não"}</p></div>
    <h2>Observações</h2><p>{r.notes || "Sem observações."}</p><AuditTrail rows={audit}/>
  </AdminPage>;
}
