import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/auth";
import { AdminPage } from "@/components/AdminPage";
import { AuditTrail } from "@/components/AuditTrail";

const state = (value: string) => ({ DRAFT: "Rascunho", FINALIZED: "Finalizado", CANCELLED: "Cancelado" }[value] ?? value);
const oil = (value: string | null) => value ? ({ LOW: "Baixo", NORMAL: "Normal", HIGH: "Alto" }[value] ?? value) : "—";

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  await requireAdmin(); const { id } = await params;
  const r = await db.machineCheckup.findUnique({ where: { id: Number(id) }, include: { machine: true, operator: true } });
  if (!r) notFound();
  const audit = await db.auditLog.findMany({ where: { entity: "MachineCheckup", entityId: String(r.id) }, include: { user: true }, orderBy: { createdAt: "asc" } });
  return <AdminPage title={`Check-up da máquina ${r.machine.code}`} subtitle="Detalhes do controlo realizado.">
    <div className="detail-grid"><p><b>Data:</b> {r.observedAt.toLocaleString("pt-PT")}</p><p><b>Criado por:</b> {r.operator.name}</p><p><b>Turno:</b> {r.shiftCode}</p><p><b>Estado:</b> {state(r.status)}</p><p><b>Temperatura do óleo:</b> {String(r.oilTempC ?? "—")} °C</p><p><b>Nível do óleo:</b> {oil(r.oilLevel)}</p><p><b>Temperatura do molde:</b> {String(r.mouldTempC ?? "—")} °C</p><p><b>Pressão de ar:</b> {String(r.airPressure ?? "—")} bar</p></div>
    <h2>Observações</h2><p>{r.notes || "Sem observações."}</p><AuditTrail rows={audit}/>
  </AdminPage>;
}
