"use client";
import { useActionState } from "react";
import { loginAction } from "@/app/actions/auth";
import { LockKeyhole, LogIn } from "lucide-react";

export default function LoginPage() {
  const [state, action, pending] = useActionState(loginAction, undefined);
  return <main className="login-shell"><section className="login-card">
    <div className="brand brand-dark"><span className="brand-mark">S</span><div><strong>SODILAVE</strong><small>PLÁSTICOS</small></div></div>
    <h1>Bem-vindo</h1><p>Introduza o seu PIN para continuar</p>
    <form action={action}>
      <label>PIN</label>
      <div className="input-icon"><LockKeyhole size={22}/><input name="pin" type="password" inputMode="numeric" pattern="[0-9]*" minLength={4} maxLength={8} placeholder="Introduza o seu PIN" autoFocus required/></div>
      {state?.error && <div className="alert error">{state.error}</div>}
      <button className="btn primary full" disabled={pending}><LogIn size={20}/>{pending ? "A entrar..." : "Entrar"}</button>
    </form>
    <p className="muted small">Acesso restrito a colaboradores autorizados</p>
  </section></main>;
}
