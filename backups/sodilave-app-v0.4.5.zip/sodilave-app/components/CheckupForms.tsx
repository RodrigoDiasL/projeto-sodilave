"use client";
import { useState } from "react";
import { saveGeneralCheck, saveMachineCheckup } from "@/app/actions/checkups";

export function CheckupForms({ machines }: { machines: { id: number; code: string; name: string }[] }) {
  const [msg, setMsg] = useState("");
  const [error, setError] = useState("");
  const machineAction = async (fd: FormData) => {
    setMsg(""); setError("");
    if (fd.get("intent") === "finalize" && !confirm("Finalizar este check-up?")) return;
    try { const r = await saveMachineCheckup(fd); setMsg(r.finalized ? "Check-up da máquina finalizado." : "Rascunho do check-up gravado. Pode completar os dados mais tarde."); }
    catch (e) { setError(e instanceof Error ? e.message : "Não foi possível guardar o check-up."); }
  };
  const generalAction = async (fd: FormData) => {
    setMsg(""); setError("");
    if (fd.get("intent") === "finalize" && !confirm("Finalizar o check-up geral?")) return;
    try { const r = await saveGeneralCheck(fd); setMsg(r.finalized ? "Check-up geral finalizado." : "Rascunho geral gravado. Pode completar os dados mais tarde."); }
    catch (e) { setError(e instanceof Error ? e.message : "Não foi possível guardar o check-up geral."); }
  };
  return <div className="checkup-layout">
    <form action={machineAction} className="panel form-stack"><h2>Check-up da máquina</h2><p className="muted small">Pode gravar um rascunho incompleto. Todos os campos obrigatórios são verificados ao finalizar.</p>
      <fieldset><legend>Selecione a máquina *</legend><div className="machine-grid">{machines.map((m) => <label className="machine-option" key={m.id}><input type="radio" name="machineId" value={m.id} required/><span>⚙</span><strong>{m.code}</strong></label>)}</div></fieldset>
      <section className="subpanel"><h3>Sistema hidráulico</h3><div className="two-col"><label>Temperatura do óleo hidráulico (°C) *<input name="oilTempC" className="no-spinner" type="number" step="0.1" min="-20" max="150" inputMode="decimal" placeholder="Ex.: 45" required/></label><label>Nível do óleo hidráulico *<select name="oilLevel" required><option value="">Selecione</option><option value="LOW">Baixo</option><option value="NORMAL">Normal</option><option value="HIGH">Alto</option></select></label></div></section>
      <section className="subpanel"><h3>Molde e ar</h3><div className="two-col"><label>Temperatura do molde (°C) *<input name="mouldTempC" className="no-spinner" type="number" step="0.1" min="-20" max="250" inputMode="decimal" placeholder="Ex.: 60" required/></label><label>Pressão de ar (bar) *<input name="airPressure" className="no-spinner" type="number" step="0.1" min="0" max="50" inputMode="decimal" placeholder="Ex.: 6,5" required/></label></div></section>
      <label>Observações<textarea name="notes" maxLength={500} placeholder="Escreva aqui observações ou comentários..."/></label>
      <div className="button-row"><button className="btn secondary" name="intent" value="draft" formNoValidate>Gravar rascunho</button><button className="btn primary" name="intent" value="finalize">Finalizar check-up</button></div>
    </form>
    <form action={generalAction} className="panel form-stack"><h2>Check-up geral do turno</h2><p className="muted small">Pode gravar um rascunho incompleto. As temperaturas são verificadas ao finalizar.</p>
      <section className="subpanel"><h3>Refrigeradores</h3><div className="two-col"><label>Refrigerador grande (°C) *<input name="chillerLargeC" className="no-spinner" type="number" step="0.1" min="-30" max="80" inputMode="decimal" placeholder="Ex.: 18" required/></label><label>Refrigerador pequeno (°C) *<input name="chillerSmallC" className="no-spinner" type="number" step="0.1" min="-30" max="80" inputMode="decimal" placeholder="Ex.: 18" required/></label></div></section>
      <section className="subpanel"><h3>Limpezas realizadas</h3><label className="check"><input type="checkbox" name="cleanDispatch"/>Zona de expedição</label><label className="check"><input type="checkbox" name="cleanStorage"/>Zona de armazenamento</label><label className="check"><input type="checkbox" name="cleanProduction"/>Zona de produção</label></section>
      <label>Observações gerais<textarea name="generalNotes" maxLength={500} placeholder="Escreva aqui observações ou comentários..."/></label>
      <div className="button-row"><button className="btn secondary" name="intent" value="draft" formNoValidate>Gravar rascunho</button><button className="btn primary" name="intent" value="finalize">Finalizar check-up geral</button></div>
    </form>
    {error && <div className="alert error span-all">{error}</div>}{msg && <div className="alert success span-all">{msg}</div>}
  </div>;
}
