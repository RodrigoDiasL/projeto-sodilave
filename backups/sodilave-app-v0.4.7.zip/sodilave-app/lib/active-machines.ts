import { db } from "@/lib/db";

export async function getActiveWeeklyMachineIds() {
  const startup = await db.weeklyStartup.findFirst({
    where: { status: "FINALIZED" },
    orderBy: [{ startupDate: "desc" }, { id: "desc" }],
    include: { machines: { select: { machineId: true } } },
  });
  return startup?.machines.map((item) => item.machineId) ?? [];
}

export async function getActiveWeeklyMachines() {
  const ids = await getActiveWeeklyMachineIds();
  if (!ids.length) return [];
  return db.machine.findMany({
    where: { active: true, id: { in: ids } },
    orderBy: { code: "asc" },
  });
}

export async function assertMachineRunning(machineId: number) {
  const ids = await getActiveWeeklyMachineIds();
  if (!ids.includes(machineId)) {
    throw new Error("A máquina selecionada não consta do último arranque semanal registado.");
  }
}
