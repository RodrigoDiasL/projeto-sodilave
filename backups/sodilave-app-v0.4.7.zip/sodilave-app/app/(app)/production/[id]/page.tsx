import { notFound } from "next/navigation";
import { PageIntro } from "@/components/PageIntro";
import { ProductionForm } from "@/components/ProductionForm";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { getProductionFormData } from "@/lib/production-form-data";
import { productionToInitial } from "@/lib/production-initial";

export default async function EditProductionPage({ params }: { params: Promise<{ id: string }> }) {
  await requireUser();
  const { id } = await params;
  const production = await db.production.findUnique({
    where: { id: Number(id) },
    include: { materials: { include: { rawMaterialLot: true } }, tests: true },
  });
  if (!production || production.status !== "DRAFT") notFound();
  const data = await getProductionFormData();
  const initial = productionToInitial(production);

  return <>
    <PageIntro title={`Continuar produção ${production.productionLot}`} subtitle="Atualize o rascunho e finalize quando o registo estiver completo." />
    <ProductionForm {...data} initial={initial} />
  </>;
}
