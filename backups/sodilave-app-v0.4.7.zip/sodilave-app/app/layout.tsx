import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "Sodilave | Gestão de Produção", description: "Aplicação interna de gestão de produção" };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="pt"><body>{children}</body></html>}
