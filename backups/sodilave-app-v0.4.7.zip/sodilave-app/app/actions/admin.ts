"use server";
import bcrypt from "bcryptjs";
import { revalidatePath } from "next/cache";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";
import { UserRole } from "@prisma/client";

const text = (fd: FormData, key: string, max = 120) => String(fd.get(key) || "").trim().slice(0, max);
const positiveNumber = (fd: FormData, key: string, label: string, max = 999999999) => {
  const value = Number(fd.get(key));
  if (!Number.isFinite(value) || value <= 0 || value > max) throw new Error(`${label} tem um valor inválido.`);
  return value;
};
const positiveId = (fd: FormData) => {
  const id = Number(fd.get("id"));
  if (!Number.isInteger(id) || id <= 0) throw new Error("Identificador inválido.");
  return id;
};
const requireText = (value: string, label: string) => { if (!value) throw new Error(`${label} é obrigatório.`); return value; };

export async function createUser(formData: FormData) {
  const admin = await requireAdmin();
  const name = requireText(text(formData, "name"), "O nome");
  const pin = text(formData, "pin", 8);
  const role = text(formData, "role", 20) as UserRole;
  if (!/^\d{4,8}$/.test(pin)) throw new Error("O PIN deve ter entre 4 e 8 algarismos.");
  if (!Object.values(UserRole).includes(role)) throw new Error("Perfil inválido.");
  const row = await db.user.create({ data: { name, pinHash: await bcrypt.hash(pin, 12), role, active: true } });
  await db.auditLog.create({ data: { userId: admin.id, action: "CREATE", entity: "User", entityId: String(row.id) } });
  revalidatePath("/admin/users");
}


export async function updateUser(formData: FormData) {
  const admin = await requireAdmin();
  const id = positiveId(formData);
  const name = requireText(text(formData, "name"), "O nome");
  const pin = text(formData, "pin", 8);
  const role = text(formData, "role", 20) as UserRole;
  const active = formData.get("active") === "on";
  if (!Object.values(UserRole).includes(role)) throw new Error("Perfil inválido.");
  if (pin && !/^\d{4,8}$/.test(pin)) throw new Error("O novo PIN deve ter entre 4 e 8 algarismos.");
  if (id === admin.id && (!active || role !== UserRole.ADMIN)) throw new Error("Não pode retirar o seu próprio acesso de administrador nem desativar a conta com sessão iniciada.");
  const data: { name: string; role: UserRole; active: boolean; pinHash?: string } = { name, role, active };
  if (pin) data.pinHash = await bcrypt.hash(pin, 12);
  await db.user.update({ where: { id }, data });
  await db.auditLog.create({ data: { userId: admin.id, action: "EDIT", entity: "User", entityId: String(id), details: { name, role, active, pinChanged: Boolean(pin) } } });
  revalidatePath("/admin/users");
}

export async function createMachine(formData: FormData) {
  await requireAdmin();
  await db.machine.create({ data: { code: requireText(text(formData, "code", 30), "O código"), name: requireText(text(formData, "name"), "O nome"), active: true } });
  revalidatePath("/admin/machines");
}
export async function createProduct(formData: FormData) {
  await requireAdmin();
  await db.product.create({ data: { code: requireText(text(formData, "code", 40), "O código"), name: requireText(text(formData, "name"), "A designação"), packageType: text(formData, "packageType") || null, active: true } });
  revalidatePath("/admin/products");
}
export async function createRawMaterial(formData: FormData) {
  await requireAdmin();
  await db.rawMaterial.create({ data: {
    code: requireText(text(formData, "code", 40), "O código"),
    name: requireText(text(formData, "name"), "A designação"),
    materialType: text(formData, "materialType", 60) || null,
    color: text(formData, "color", 60) || null,
    manufacturer: text(formData, "manufacturer", 120) || null,
    internalReference: text(formData, "internalReference", 80) || null,
    notes: text(formData, "notes", 500) || null,
    unit: "kg", active: true
  } });
  revalidatePath("/admin/raw-materials");
}
export async function updateRawMaterial(formData: FormData) {
  await requireAdmin(); const id = positiveId(formData);
  await db.rawMaterial.update({ where: { id }, data: {
    code: requireText(text(formData, "code", 40), "O código"),
    name: requireText(text(formData, "name"), "A designação"),
    materialType: text(formData, "materialType", 60) || null,
    color: text(formData, "color", 60) || null,
    manufacturer: text(formData, "manufacturer", 120) || null,
    internalReference: text(formData, "internalReference", 80) || null,
    notes: text(formData, "notes", 500) || null,
    active: formData.get("active") === "on", unit: "kg"
  } });
  revalidatePath("/admin/raw-materials"); revalidatePath("/production");
}
export async function createRawMaterialLot(formData: FormData) {
  await requireAdmin();
  const rawMaterialId = Number(formData.get("rawMaterialId"));
  if (!Number.isInteger(rawMaterialId) || rawMaterialId <= 0) throw new Error("Selecione uma matéria-prima.");
  const quantity = positiveNumber(formData, "quantityInitial", "A quantidade");
  await db.rawMaterialLot.create({ data: { rawMaterialId, supplierLot: requireText(text(formData, "supplierLot", 80), "O lote do fornecedor"), supplier: text(formData, "supplier") || null, quantityInitial: quantity, quantityAvailable: quantity } });
  revalidatePath("/admin/raw-material-lots"); revalidatePath("/production");
}

export async function updateRawMaterialLot(formData: FormData) {
  const admin = await requireAdmin();
  const id = positiveId(formData);
  const rawMaterialId = Number(formData.get("rawMaterialId"));
  if (!Number.isInteger(rawMaterialId) || rawMaterialId <= 0) throw new Error("Selecione uma matéria-prima.");
  const quantityInitial = positiveNumber(formData, "quantityInitial", "A quantidade inicial");
  const quantityAvailableValue = Number(formData.get("quantityAvailable"));
  if (!Number.isFinite(quantityAvailableValue) || quantityAvailableValue < 0 || quantityAvailableValue > quantityInitial) throw new Error("A quantidade disponível deve estar entre 0 e a quantidade inicial.");
  const status = text(formData, "status", 20);
  if (!["ACTIVE", "DEPLETED", "CLOSED", "CANCELLED"].includes(status)) throw new Error("Estado do lote inválido.");
  await db.rawMaterialLot.update({ where: { id }, data: {
    rawMaterialId,
    supplierLot: requireText(text(formData, "supplierLot", 80), "O lote do fornecedor"),
    supplier: text(formData, "supplier") || null,
    quantityInitial,
    quantityAvailable: quantityAvailableValue,
    status: status as any,
  } });
  await db.auditLog.create({ data: { userId: admin.id, action: "EDIT", entity: "RawMaterialLot", entityId: String(id) } });
  revalidatePath("/admin/raw-material-lots"); revalidatePath("/production");
}

export async function createLotRule(formData: FormData) {
  await requireAdmin();
  await db.productionLotRule.updateMany({ data: { active: false } });
  await db.productionLotRule.create({ data: { name: requireText(text(formData, "name"), "O nome"), prefix: requireText(text(formData, "prefix", 20), "O prefixo"), template: requireText(text(formData, "template", 200), "O modelo"), active: true } });
  revalidatePath("/admin/lot-rules");
}

export async function deleteMachine(formData: FormData) {
  await requireAdmin(); const id = positiveId(formData);
  const [productions, checkups] = await Promise.all([db.production.count({ where: { machineId: id } }), db.machineCheckup.count({ where: { machineId: id } })]);
  if (productions || checkups) await db.machine.update({ where: { id }, data: { active: false } }); else await db.machine.delete({ where: { id } });
  revalidatePath("/admin/machines"); revalidatePath("/production"); revalidatePath("/checkups");
}
export async function deleteProduct(formData: FormData) {
  await requireAdmin(); const id = positiveId(formData);
  if (await db.production.count({ where: { productId: id } })) await db.product.update({ where: { id }, data: { active: false } }); else await db.product.delete({ where: { id } });
  revalidatePath("/admin/products"); revalidatePath("/production");
}
export async function deleteRawMaterial(formData: FormData) {
  await requireAdmin(); const id = positiveId(formData);
  if (await db.rawMaterialLot.count({ where: { rawMaterialId: id } })) await db.rawMaterial.update({ where: { id }, data: { active: false } }); else await db.rawMaterial.delete({ where: { id } });
  revalidatePath("/admin/raw-materials"); revalidatePath("/production");
}
export async function deleteRawMaterialLot(formData: FormData) {
  await requireAdmin(); const id = positiveId(formData);
  if (await db.productionMaterial.count({ where: { rawMaterialLotId: id } })) await db.rawMaterialLot.update({ where: { id }, data: { status: "CANCELLED" } }); else await db.rawMaterialLot.delete({ where: { id } });
  revalidatePath("/admin/raw-material-lots"); revalidatePath("/production");
}
export async function deleteUser(formData: FormData) {
  const admin = await requireAdmin(); const id = positiveId(formData);
  if (id === admin.id) throw new Error("Não pode eliminar o utilizador com sessão iniciada.");
  const references = await Promise.all([db.production.count({ where: { operatorId: id } }), db.machineCheckup.count({ where: { operatorId: id } }), db.shiftGeneralCheck.count({ where: { operatorId: id } })]);
  if (references.some(Boolean)) await db.user.update({ where: { id }, data: { active: false } }); else await db.user.delete({ where: { id } });
  revalidatePath("/admin/users");
}
export async function deleteLotRule(formData: FormData) {
  await requireAdmin(); const id = positiveId(formData);
  const rule = await db.productionLotRule.findUniqueOrThrow({ where: { id } });
  if (rule.active) throw new Error("Ative outra regra antes de eliminar a regra atual.");
  await db.productionLotRule.delete({ where: { id } });
  revalidatePath("/admin/lot-rules");
}
export async function deleteProduction(formData: FormData) {
  await requireAdmin(); const id = positiveId(formData);
  await db.production.delete({ where: { id } }); revalidatePath("/admin/productions");
}
export async function deleteMachineCheckup(formData: FormData) {
  await requireAdmin(); const id = positiveId(formData);
  await db.machineCheckup.delete({ where: { id } }); revalidatePath("/admin/checkups");
}
export async function deleteGeneralCheckup(formData: FormData) {
  await requireAdmin(); const id = positiveId(formData);
  await db.shiftGeneralCheck.delete({ where: { id } }); revalidatePath("/admin/checkups");
}
