"use server";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { getShift } from "@/lib/shift";
import { OilLevel, RecordStatus } from "@prisma/client";
const n=(v:FormDataEntryValue|null)=>v===null||v===""?null:Number(v);
const check=(v:number|null,min:number,max:number,label:string)=>{if(v===null||!Number.isFinite(v)||v<min||v>max)throw new Error(`${label} tem um valor inválido.`)};

export async function saveMachineCheckup(formData: FormData) {
  const user=await requireUser(); const intent=String(formData.get("intent")||"draft");
  if(!['draft','finalize'].includes(intent))throw new Error('Ação inválida.');
  const status=intent==="finalize"?RecordStatus.FINALIZED:RecordStatus.DRAFT;
  const id=n(formData.get("checkupId")); const machineId=Number(formData.get("machineId"));
  if(!Number.isInteger(machineId)||machineId<=0)throw new Error('Selecione uma máquina.');
  const oilTempC=n(formData.get("oilTempC")), mouldTempC=n(formData.get("mouldTempC")), airPressure=n(formData.get("airPressure"));
  check(oilTempC,-20,150,'A temperatura do óleo'); check(mouldTempC,-20,250,'A temperatura do molde'); check(airPressure,0,50,'A pressão de ar');
  const oilLevel=String(formData.get("oilLevel")||"") as OilLevel;
  if(!Object.values(OilLevel).includes(oilLevel))throw new Error('Selecione o nível do óleo.');
  const data={ machineId, operatorId:user.id, shiftCode:getShift().code, status, oilTempC, oilLevel, mouldTempC, airPressure,
    notes:String(formData.get("notes")||"").trim().slice(0,500)||null, finalizedAt:status===RecordStatus.FINALIZED?new Date():null };
  const row=id?await db.machineCheckup.update({where:{id},data}):await db.machineCheckup.create({data});
  await db.auditLog.create({data:{userId:user.id,action:status===RecordStatus.FINALIZED?"FINALIZE":"SAVE",entity:"MachineCheckup",entityId:String(row.id)}});
  revalidatePath("/checkups"); revalidatePath('/admin/checkups'); return {ok:true,id:row.id,finalized:status===RecordStatus.FINALIZED};
}

export async function saveGeneralCheck(formData: FormData) {
  const user=await requireUser(); const intent=String(formData.get("intent")||"draft");
  if(!['draft','finalize'].includes(intent))throw new Error('Ação inválida.');
  const status=intent==="finalize"?RecordStatus.FINALIZED:RecordStatus.DRAFT; const id=n(formData.get("generalId"));
  const chillerLargeC=n(formData.get("chillerLargeC")), chillerSmallC=n(formData.get("chillerSmallC"));
  check(chillerLargeC,-30,80,'A temperatura do refrigerador grande'); check(chillerSmallC,-30,80,'A temperatura do refrigerador pequeno');
  const data={ operatorId:user.id, shiftCode:getShift().code, status, chillerLargeC, chillerSmallC,
    cleanDispatch:formData.get("cleanDispatch")==="on",cleanStorage:formData.get("cleanStorage")==="on",cleanProduction:formData.get("cleanProduction")==="on",
    notes:String(formData.get("generalNotes")||"").trim().slice(0,500)||null,finalizedAt:status===RecordStatus.FINALIZED?new Date():null };
  const row=id?await db.shiftGeneralCheck.update({where:{id},data}):await db.shiftGeneralCheck.create({data});
  await db.auditLog.create({data:{userId:user.id,action:status===RecordStatus.FINALIZED?"FINALIZE":"SAVE",entity:"ShiftGeneralCheck",entityId:String(row.id)}});
  revalidatePath("/checkups"); revalidatePath('/admin/checkups'); return {ok:true,id:row.id,finalized:status===RecordStatus.FINALIZED};
}
