import { PageIntro } from "@/components/PageIntro";
import { ProductionForm } from "@/components/ProductionForm";
import { getProductionFormData } from "@/lib/production-form-data";

export default async function NewProductionPage() {
  const data = await getProductionFormData();
  return <>
    <PageIntro title="Nova produção" subtitle="Registe os dados iniciais e guarde para continuar mais tarde." />
    <ProductionForm {...data} />
  </>;
}
