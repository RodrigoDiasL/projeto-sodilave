import { notFound } from "next/navigation";
import { PageIntro } from "@/components/PageIntro";
import { ProductionForm } from "@/components/ProductionForm";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { getProductionFormData } from "@/lib/production-form-data";

export default async function EditProductionPage({ params }: { params: Promise<{ id: string }> }) {
  await requireUser();
  const { id } = await params;
  const production = await db.production.findUnique({
    where: { id: Number(id) },
    include: { materials: { include: { rawMaterialLot: true } }, tests: true },
  });
  if (!production || production.status !== "DRAFT") notFound();
  const data = await getProductionFormData();
  const testMap = new Map(production.tests.map((test) => [`${test.type}_${test.moment}`, test.result]));
  const initial = {
    id: production.id,
    machineId: production.machineId,
    productId: production.productId,
    productionLot: production.productionLot,
    initialWeightG: production.initialWeightG ? String(Number(production.initialWeightG)) : "",
    midWeightG: production.midWeightG ? String(Number(production.midWeightG)) : "",
    quantityProduced: production.quantityProduced === null ? "" : String(production.quantityProduced),
    observations: production.observations ?? "",
    materials: production.materials.map((material, index) => ({
      key: material.id || index,
      materialId: String(material.rawMaterialLot.rawMaterialId),
      lotId: String(material.rawMaterialLotId),
      percentage: Number(material.percentage ?? 0),
      quantityKg: material.quantityKg === null ? "" : String(Number(material.quantityKg)),
    })),
    tests: {
      leakStart: testMap.get("LEAK_START") ?? "",
      leakMid: testMap.get("LEAK_MID") ?? "",
      dropStart: testMap.get("DROP_START") ?? "",
      dropMid: testMap.get("DROP_MID") ?? "",
    },
  };

  return <>
    <PageIntro title={`Continuar produção ${production.productionLot}`} subtitle="Atualize o rascunho e finalize quando o registo estiver completo." />
    <ProductionForm {...data} initial={initial} />
  </>;
}
