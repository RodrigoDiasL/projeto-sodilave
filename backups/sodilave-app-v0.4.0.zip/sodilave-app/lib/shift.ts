export function getShift(date = new Date()) {
  const hour = date.getHours();
  if (hour >= 0 && hour < 8) return { code: "A", label: "Turno A", hours: "00:00 - 08:00" };
  if (hour >= 8 && hour < 16) return { code: "B", label: "Turno B", hours: "08:00 - 16:00" };
  return { code: "C", label: "Turno C", hours: "16:00 - 24:00" };
}
